function [D,R]=MI_Sort(data,label,dim)

    x=[1:1:dim];
    for i=1:length(x)
       D(i)=ownmi(data(:,x(i)),label);
       R(i,i)=0;
       for j=[1:i-1,i+1:length(x)]
           R(i,j)=ownmi(data(:,x(i)),data(:,x(j)));
       end 
    end
end





