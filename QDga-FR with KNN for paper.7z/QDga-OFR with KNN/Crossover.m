

function [y1 y2]=Crossover(a,b)
   
a=sort(a);b=sort(b);
c=intersect(a,b);

if length(c)>1
m=c(1);k=1;compon{k}=[c(1)];i=1;
while i<(length(c))  
    if a(find(a==c(i))+1)==b(find(b==c(i))+1)
        compon{k}=[compon{k},c(i+1)];
        m=m+1;
        i=i+1;
    else
        k=k+1;
        compon{k}=[c(i+1)];
        i=i+1;
    end
end

elseif length(c)==1
    compon{1}=c;
else
    compon=[];
end



if length(compon)>1
     kk=randperm(length(compon));
     [ll,ka]=find(a==compon{kk(1)}(1));
     [ll,kb]=find(b==compon{kk(1)}(1));
     [ll,ja]=find(a==compon{kk(2)}(1));
     [ll,jb]=find(b==compon{kk(2)}(1));
     ma=sort([ka,ja]);mb=sort([kb,jb]);

      crossnewa=[a(1:ma(1)-1),b(mb(1):mb(2)-1),a(ma(2):end)];
      crossnewb=[b(1:mb(1)-1),a(ma(1):ma(2)-1),b(mb(2):end)];

elseif length(compon)==1
      [ll,ka]=find(a==compon{1}(1));
      [ll,kb]=find(b==compon{1}(1));
      ja=randperm(length(a));
      while ja(1)>(ka-1)&&ja(1)<(ka+length(compon{1})-1)
          ja=randperm(length(a));
      end

       jb=randperm(length(b));
       while jb(1)>(kb-1)&&jb(1)<(kb+length(compon{1})-1)
            jb=randperm(length(b));
       end
       ma=sort([ka,ja(1)]);mb=sort([kb,jb(1)]);
       crossnewa=[a(1:ma(1)-1),b(mb(1):mb(2)-1),a(ma(2):end)];
       crossnewb=[b(1:mb(1)-1),a(ma(1):ma(2)-1),b(mb(2):end)];

elseif length(compon)==0
       ja=randperm(length(a));
       jb=randperm(length(b));
       crossnewa=[a(1:ja(1)),b(jb(1)+1:end)];
       crossnewb=[b(1:jb(1)),a(ja(1)+1:end)];
end 

y1=unique(crossnewa);

y2=unique(crossnewb);
    
end