
function y=Mutate(x,mu,dim)

     a=rand;
     mu(2)=(1-mu(1))*((dim-length(x))/(dim-1));
     mu(3)=1-mu(2)-mu(1);
    
     if a<mu(1)
         y=change_mutate(x,dim);
     elseif a>=mu(1)&&a<(mu(1)+mu(2))
         y=add_mutate(x,dim);
     else
         y=delete_mutate(x,dim);
     end
     
          kk=randperm(dim);
          kk_s=kk(1);
          x=[x kk_s];
          y=unique(x); 




    function y=change_mutate(x,dim)
        
        sp=randperm(length(x));
        sele_position=sp(1);
        sm=randperm(dim);
        x(sele_position)=sm(1);
        y=unique(x);
    end


    function y=add_mutate(x,dim)
        
         kk=randperm(dim);
          kk_s=kk(1);
          x=[x kk_s];
          y=unique(x); 
    end


   function y=delete_mutate(x,dim)
       
       if length(x)>1
           
          kk=randperm(length(x)); 
          x(kk(1))=[];
          y=unique(x);
       else
           y=x;
       end
         
    end


end