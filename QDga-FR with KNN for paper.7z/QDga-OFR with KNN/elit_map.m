clc;
clear;
close all;
tic;
%% Problem Definition  load�������Ǵ������ӱ��ӵ�����

load('test_data/tic_tac_toc.mat')
rowrank =randperm(size(tic_tac_toc,1));
tic_tac_toc=tic_tac_toc(rowrank,:);
num_train=ceil(0.75*size(tic_tac_toc,1));

train_data=tic_tac_toc(1:num_train,2:end);
train_label=tic_tac_toc(1:num_train,1);
test_data=tic_tac_toc(num_train+1:end,2:end);
test_label=tic_tac_toc(num_train+1:end,1);

dim=size(train_data,2);

% [D_data,R_data]=MI_Sort(train_data,train_label,dim);
load('D_R/tic_tac_toc_D_data.mat');
load('D_R/tic_tac_toc_R_data.mat');
%% NSGA-II Parameters
MaxIt=50;%%��������������
mean_fc=5;%%%%ƽ��featurecell�Ĵ�С����dimһ��������ʼ����Ⱥ�Ĵ�С��
[nPop,nt]=parameter_set(mean_fc,dim);%%%%��ʼ����Ⱥ��featurecell��С

pCrossover=0.8;
nCrossover=round(pCrossover*nPop/2)*2;%����crossover�����¸��������

pMutation=0.4;%%%%%%%%%%%%���Ҫ����
nMutation=round(pMutation*nPop);%����mutation�����¸��������

mu=[0.2,0.3,0.5];%����mutation�����¸��������

%% Initialization
tic;
empty_individual.Position=[];
empty_individual.Cost=[];
empty_individual.Length=[];
cell_distribute=zeros(1,dim); %��ʼ��ÿ��feature cell�ĸ�����
pop=repmat(empty_individual,nPop,1);%��ʼ����Ⱥ
for i=1:nPop
    k1=randperm(dim);
    k2=k1(1:ceil((rand*dim)));
    pop(i).Position=unique(sort(k2));        %%%%%%%%%%%%%%%%%% 
    [pop(i).Position pop(i).Cost]=MyCostReduceKNN(pop(i).Position,train_data,train_label,D_data,R_data);
    pop(i).Length=length(pop(i).Position);
end

pop_new=[];
      for i=1:dim
           pop_sele=[]; 
           pop_can=[];
           pop_can_add=[];  
           pop_s=pop(find([pop.Length]==i));
           cc=reshape([pop_s.Position],i,length(pop_s))';
           [b,iorder] = unique (cc,'rows');
           pop_sele=pop_s(iorder);        
           if length(pop_sele)>nt(i)
               [value_can,rank_can]=sort([pop_sele.Cost]);
                pop_can=pop_sele(rank_can(1:nt(i)));
            elseif length(pop_sele)<nt(i)
               pop_can=pop_sele(1:length(pop_sele));
               pop_can_add=repmat(empty_individual,(nt(i)-length(pop_sele)),1);
               for ii=1:(nt(i)-length(pop_sele))
                   k1=randperm(dim);
                   k2=k1(1:i);
                   pop_can_add(ii).Position=(sort(k2));        %%%%%%%%%%%%%%%%%% 
                   pop_can_add(ii).Cost=MyCostKNN(pop_can_add(ii).Position,train_data,train_label,D_data,R_data);
                   pop_can_add(ii).Length=length(pop_can_add(ii).Position);
               end
               pop_can=[pop_can;pop_can_add];
           else
               pop_can=pop_sele;
           end
           pop_new=[pop_new;pop_can];
      end        
       pop=pop_new(randperm(length(pop_new))); 

 %%��ѭ��   
for it=1:MaxIt
    cell_size=dim;%%�̶���cell_sieze  
    popc=repmat(empty_individual,nCrossover/2,2);    
    for k=1:nCrossover/2
        
        [i1,i2]=CrossSelection(pop,cell_size);        
        [popc(k,1).Position popc(k,2).Position]=Crossover(pop(i1).Position,pop(i2).Position);         
         [popc(k,1).Position popc(k,1).Cost]=MyCostReduceKNN(popc(k,1).Position,train_data,train_label,D_data,R_data);
         popc(k,1).Length=length(popc(k,1).Position);         
        [popc(k,2).Position popc(k,2).Cost]=MyCostReduceKNN( popc(k,2).Position,train_data,train_label,D_data,R_data);
         popc(k,2).Length=length(popc(k,2).Position);     

    end
     popc=popc(:);      
     popm=repmat(empty_individual,nMutation,1);
    for k=1:nMutation      
        i=MutateSelection(pop);        
        popm(k).Position=Mutate(pop(i).Position,mu,dim);        
        [popm(k).Position popm(k).Cost]=MyCostReduceKNN(popm(k).Position,train_data,train_label,D_data,R_data);
         popm(k).Length=length(popm(k).Position);
    end
     pop=[pop;popc;popm];
      
     pop_new=[];
      for i=1:dim
           pop_sele=[]; 
           pop_can=[];
           pop_can_add=[];  
           pop_s=pop(find([pop.Length]==i));
           cc=reshape([pop_s.Position],i,length(pop_s))';
           [b,iorder] = unique (cc,'rows');
           pop_sele=pop_s(iorder);        
           if length(pop_sele)>nt(i)
               [value_can,rank_can]=sort([pop_sele.Cost]);
                pop_can=pop_sele(rank_can(1:nt(i)));
            elseif length(pop_sele)<nt(i)
               pop_can=pop_sele(1:length(pop_sele));
               pop_can_add=repmat(empty_individual,(nt(i)-length(pop_sele)),1);
               for ii=1:(nt(i)-length(pop_sele))
                   k1=randperm(dim);
                   k2=k1(1:i);
                   pop_can_add(ii).Position=(sort(k2));        %%%%%%%%%%%%%%%%%% 
                   pop_can_add(ii).Cost=MyCostKNN(pop_can_add(ii).Position,train_data,train_label,D_data,R_data);
                   pop_can_add(ii).Length=length(pop_can_add(ii).Position);
               end
               pop_can=[pop_can;pop_can_add];
           else
               pop_can=pop_sele;
           end
           pop_new=[pop_new;pop_can];
      end
         
       pop=pop_new(randperm(length(pop_new)));
       
       [kv,ks]=sort([pop.Length]);
       pop=pop(ks);
       [kv1,ks1]=sort([pop.Cost]);
       pop=pop(ks1);
       record_c(it)=pop(1).Cost;
       record_l(it)=pop(1).Length;
       
       tic_tac_toc_train_data=train_data(:,pop(1).Position);
       tic_tac_toc_train_label=train_label;
       tic_tac_toc_test_data=test_data(:,pop(1).Position);
       tic_tac_toc_test_label=test_label;
       mdl = ClassificationKNN.fit(tic_tac_toc_train_data,tic_tac_toc_train_label,'NumNeighbors',1);
       predict_label   =       predict(mdl, tic_tac_toc_test_data);
       accuracy         =       length(find(predict_label == tic_tac_toc_test_label))/length(test_label)*100;  
       record_t(it)=1-0.01*accuracy;
       

      it
      
end
save  KNN_result/tic_tac_toc_record_c.txt -ascii record_c;
save  KNN_result/tic_tac_toc_record_l.txt -ascii record_l;
save  KNN_result/tic_tac_toc_record_t.txt -ascii record_t;



tic_tac_toc_validation_error=pop(1).Cost;
tic_tac_toc_selected_feature=pop(1).Position;

save_cost=[pop.Cost];
save_length=[pop.Length];
scl=[save_cost;save_length];
tic_tac_toc_mean_length=mean([pop.Length]);
save  KNN_result/tic_tac_toc_mean_length.txt -ascii tic_tac_toc_mean_length;
save  KNN_result/tic_tac_toc_cost_length.txt -ascii scl;
save  KNN_result/tic_tac_toc_selected_feature.txt -ascii tic_tac_toc_selected_feature;
save  KNN_result/tic_tac_toc_validation_error.txt -ascii tic_tac_toc_validation_error;



tic_tac_toc_train_data=train_data(:,tic_tac_toc_selected_feature);
tic_tac_toc_train_label=train_label;
tic_tac_toc_test_data=test_data(:,tic_tac_toc_selected_feature);
tic_tac_toc_test_label=test_label;

mdl = ClassificationKNN.fit(tic_tac_toc_train_data,tic_tac_toc_train_label,'NumNeighbors',1);
predict_label   =       predict(mdl, tic_tac_toc_test_data);
accuracy         =       length(find(predict_label == tic_tac_toc_test_label))/length(test_label)*100;
tic_tac_toc_test_error=1-0.01*accuracy ;


save KNN_result/tic_tac_toc_test_error.txt -ascii tic_tac_toc_test_error;

toc;

