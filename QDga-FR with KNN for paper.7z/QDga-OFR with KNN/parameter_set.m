function [nPop,nt]=parameter_set(m,dim)

    for i=1:ceil(1/6*dim)
        nt(i)=1;
    end
    for i=ceil(1/6*dim)+1:ceil(2/6*dim)
        nt(i)=m;
    end
    for i=ceil(2/6*dim)+1:ceil(4/6*dim)
        nt(i)=2*m;
    end
    for i=ceil(4/6*dim)+1:ceil(5/6*dim)
        nt(i)=m;
    end
    for i=ceil(5/6*dim)+1:dim
        nt(i)=1;
    end
    nt(dim)=1;
    nPop=sum(nt);
 




