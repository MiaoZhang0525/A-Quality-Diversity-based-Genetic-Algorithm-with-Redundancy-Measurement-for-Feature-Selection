%%%%��Ҫ����position�ĳ��ȣ�����ÿ��feature�ṩ��importance��ɾ����ЩimportanceΪ0 ��feature
%%%%pop(i).Position=; pop(i).Length=�� pop(i).Cost

function pc=MyCostKNN(x,data,label,D_data,R_data)

x_dele=x;

rowrank =randperm(size(data, 1));
data=data(rowrank, :);
label=label(rowrank, :);
nt=floor(1/3*size(data,1));

for k=1:5
    rowrank =randperm(size(data, 1));
    data=data(rowrank, :);
    label=label(rowrank, :);
   X=data(:,x_dele);
   Y=label;
    kt=[1:(3-1)*nt];
    kv=[((3-1)*nt+1):size(data,1)];

   train_data=X(kt,:);
    train_label=Y(kt,:);
    test_data= X(kv,:);
    test_label=Y(kv,:);

   mdl = ClassificationKNN.fit(train_data,train_label,'NumNeighbors',1);%%%%%%%%%%%�˴��仯
   predict_label   =       predict(mdl, test_data);
   accuracy         =       length(find(predict_label == test_label))/length(test_label); 
   E(k)=1-accuracy;
end

fit_o=mean(E);
     pc=fit_o; 
end




