
function pop_sele=select(pop,m,dim,cell_size,data,lable)

k_length=[pop.Length]';
ki=unique(k_length);
pos_posi={};
for i=1:length(ki)
    ks=find(k_length==ki(i));
    popw_posi=[];
    for j=1:length(ks)
        popw_posi=[popw_posi;pop(ks(j)).Position];
    end
    pp=unique(popw_posi,'rows');
    
    for j=1:size(pp,1)
        kk=cell(1);kk{1}=pp(j,:);
        pos_posi=cat(1,pos_posi,kk);
    end
end

   
empty_individual.Position=[];
empty_individual.Cost=[];
empty_individual.FeatureCell=[];
empty_individual.Length=[];

pop_pos=repmat(empty_individual,length(pos_posi),1);

for i=1:length(pos_posi)
    pop_pos(i).Position=pos_posi{i};
    pop_pos(i).Length=length(pop_pos(i).Position);
    pop_pos(i).Cost=MyCost(pop_pos(i).Position,data,lable);
    pop_pos(i).FeatureCell=ceil(length(pop_pos(i).Position)/dim*cell_size);
end


if length(pos_posi)>m
   pl=[pop_pos.Length]';
   [pv,ps]=sort(pl);
   pop_pos=pop_pos(ps);%%%%%%%%%%%%%%%���Ӷ��ڳ��ȵ�����
   kk=[pop_pos.Cost]';
   [kv,ks]=sort(kk);
   pop_sele=pop_pos(ks(1:m));
elseif length(pos_posi)==m
   pop_sele=pop_pos;
else
    add_n=m-length(pos_posi);
    pop_add=repmat(empty_individual,add_n,1);
    for i=1:add_n
        k1=randperm(dim);
        ll=pop_pos(1).FeatureCell;
        ll_d=floor(ll*dim/cell_size)- floor((ll-1)*dim/cell_size);
        ll_l=ceil(floor((ll-1)*dim/cell_size)+rand*ll_d);
        k2=k1(1:ll_l);
        pop_add(i).Position=unique(sort(k2));       
        pop_add(i).Length=length(pop_add(i).Position);
        pop_add(i).Cost=MyCost(pop_add(i).Position,data,lable);
        pop_add(i).FeatureCell=ceil(length(pop_add(i).Position)/dim*cell_size);
    end
    pop_sele=[pop_pos;pop_add];


end
end



