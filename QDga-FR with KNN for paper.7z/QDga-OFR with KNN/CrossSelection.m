
function [i1,i2]=CrossSelection(pop,cell_size)
%%%%%%%%%%%%%%%%���ѡ��һ������feature space�ĸ���
rr=randperm(length(pop));
r1=rr(1);
r2=rr(2);
if pop(r1).Cost<pop(r2).Cost
      i1=r1;
else      
      i1=r2;
end

fcv=pop(i1).Length;
if fcv==cell_size
    i2_c1=[];iii=1;
    while length(i2_c1)==0
    i2_c1=find([pop.Length]'==fcv-iii);
    iii=iii+1;
    end
    i2_c2=find([pop.Length]'==fcv);
    i2_c=[i2_c1;i2_c2];
    cs=randperm(length(i2_c));
    if pop(cs(1)).Cost<pop(cs(2)).Cost
      i2=cs(1);
    elseif pop(cs(1)).Cost==pop(cs(2)).Cost&&pop(cs(1)).Length<pop(cs(2)).Length%%%%%%%%%%%%%%%���Ӷ��ڳ��ȵ�����
        i2=cs(1);
    else      
      i2=cs(2);
    end
elseif fcv==1
    i2_c1=[];iii=1;
    while length(i2_c1)==0
    i2_c1=find([pop.Length]'==fcv+iii);
    iii=iii+1;
    end
    
    i2_c2=find([pop.Length]'==fcv);
    i2_c=[i2_c1;i2_c2];
    cs=randperm(length(i2_c));    
     if pop(cs(1)).Cost<pop(cs(2)).Cost
      i2=cs(1);
     elseif pop(cs(1)).Cost==pop(cs(2)).Cost&&pop(cs(1)).Length<pop(cs(2)).Length
        i2=cs(1); 
     else      
      i2=cs(2);
    end
else
    i2_c1=find([pop.Length]'==fcv+1);
    i2_c2=find([pop.Length]'==fcv);
    i2_c3=find([pop.Length]'==fcv-1);
    i2_c=[i2_c1;i2_c2;i2_c3];
    cs=randperm(length(i2_c));  
    if length(i2_c)==1
        i2=cs(1);
    else
       if pop(cs(1)).Cost<pop(cs(2)).Cost
           i2=cs(1);
       elseif pop(cs(1)).Cost==pop(cs(2)).Cost&&pop(cs(1)).Length<pop(cs(2)).Length
           i2=cs(1);
       else      
           i2=cs(2);
       end
    end
end


end




