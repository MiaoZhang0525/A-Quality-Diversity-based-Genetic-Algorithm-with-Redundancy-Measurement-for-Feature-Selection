function k=ownmi(a,b)

      mi=0;
      if size(a,1)==1
          d=[a',b'];
      elseif size(a,2)==1
          d=[a,b];
      end
      d1=d;
      N=length(a);
      while size(d,1)~=0
            kk=ismember(d,d(1,:),'rows');
            p=length(find(kk)==1)/N;
            k1=find(d1(:,1)==d(1,1));
            k2=find(d1(:,2)==d(1,2));
            p1=length(k1)/N;
            p2=length(k2)/N;
            d(find(kk),:)=[];           
            mi=mi+p*(log(p/(p1*p2))/log(2));
      end
      k=mi;
end